# Screenshots

Place the required screenshot for Exercise A in this folder.

Suggested filename:
`github-first-commit.png`

The screenshot should show the GitHub repository after the first successful push, including the repository name, project files, `main` branch, and the Initial commit.
